import { useState, useEffect, useCallback, useRef } from 'react'
import { CalIcon } from './components/Icons'

const FREQUENCIES = [
  { id: 'weekly',      label: 'Weekly',       desc: 'Every week' },
  { id: 'biweekly',   label: 'Bi-Weekly',    desc: 'Every 2 weeks' },
  { id: 'semimonthly',label: 'Semi-Monthly', desc: 'Twice a month' },
  { id: 'monthly',    label: 'Monthly',      desc: 'Once a month' },
]

const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']


// ── All date math is done in UTC so system timezone never affects day-of-week ──
// Create a UTC midnight date — immune to system timezone
function utcDate(y, m, d) {
  return new Date(Date.UTC(y, m, d))
}

// Parse "YYYY-MM-DD" as UTC midnight
function parseDate(str) {
  if (!str) return null
  const [y, m, d] = str.split('-').map(Number)
  return utcDate(y, m - 1, d)
}

// UTC helper getters
const D   = (d) => d.getUTCDate()
const M   = (d) => d.getUTCMonth()
const Y   = (d) => d.getUTCFullYear()
const DAY = (d) => d.getUTCDay()

// Add dayOffset to each computed date, collect those still in target month
function applyOffset(rawDates, dayOffset, year, month) {
  if (dayOffset === 0) return rawDates
  const shifted = new Set()
  rawDates.forEach(day => {
    const d = utcDate(year, month, day + dayOffset)
    if (Y(d) === year && M(d) === month) shifted.add(D(d))
  })
  return shifted
}

function getPayDates(frequency, startDate, year, month, dayOffset = 0) {
  const rawDates = new Set()
  if (!startDate) return rawDates

  const start = parseDate(startDate)
  const monthStart = utcDate(year, month, 1)
  const monthEnd   = utcDate(year, month + 1, 0) // last day of month

  if (frequency === 'weekly') {
    let d = new Date(start)
    while (d > monthEnd) d = utcDate(Y(d), M(d), D(d) - 7)
    while (d < monthStart) d = utcDate(Y(d), M(d), D(d) + 7)
    while (d <= monthEnd) {
      if (d >= monthStart) rawDates.add(D(d))
      d = utcDate(Y(d), M(d), D(d) + 7)
    }
  }

  if (frequency === 'biweekly') {
    let d = new Date(start)
    while (d > monthEnd) d = utcDate(Y(d), M(d), D(d) - 14)
    while (d < monthStart) d = utcDate(Y(d), M(d), D(d) + 14)
    while (d <= monthEnd) {
      if (d >= monthStart) rawDates.add(D(d))
      d = utcDate(Y(d), M(d), D(d) + 14)
    }
  }

  if (frequency === 'semimonthly') {
    const day1 = D(start)
    const lastDay = D(utcDate(year, month + 1, 0))
    const day2 = Math.min(day1 + 15, lastDay)
    rawDates.add(Math.min(day1, lastDay))
    rawDates.add(Math.min(day2, lastDay))
  }

  if (frequency === 'monthly') {
    const day = D(start)
    const lastDay = D(utcDate(year, month + 1, 0))
    rawDates.add(Math.min(day, lastDay))
  }

  return applyOffset(rawDates, dayOffset, year, month)
}

const SHORT_DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
const SHORT_MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

function getUpcomingPayDates(frequency, startDate, fromDate, count = 4, dayOffset = 0) {
  if (!startDate) return []
  const results = []
  const start = parseDate(startDate)
  const from = fromDate

  if (frequency === 'weekly') {
    let d = new Date(start)
    while (d <= from) d = utcDate(Y(d), M(d), D(d) + 7)
    while (results.length < count) {
      results.push(utcDate(Y(d), M(d), D(d) + dayOffset))
      d = utcDate(Y(d), M(d), D(d) + 7)
    }
  }

  if (frequency === 'biweekly') {
    let d = new Date(start)
    while (d <= from) d = utcDate(Y(d), M(d), D(d) + 14)
    while (results.length < count) {
      results.push(utcDate(Y(d), M(d), D(d) + dayOffset))
      d = utcDate(Y(d), M(d), D(d) + 14)
    }
  }

  if (frequency === 'semimonthly') {
    const day1 = D(start)
    const day2 = day1 + 15
    let y = Y(from), m = M(from)
    while (results.length < count) {
      const lastDay = D(utcDate(y, m + 1, 0))
      const d1 = utcDate(y, m, Math.min(day1, lastDay) + dayOffset)
      const d2 = utcDate(y, m, Math.min(day2, lastDay) + dayOffset)
      if (d1 > from) results.push(d1)
      if (results.length < count && d2 > from) results.push(d2)
      m++; if (m > 11) { m = 0; y++ }
    }
  }

  if (frequency === 'monthly') {
    const day = D(start)
    let y = Y(from), m = M(from)
    while (results.length < count) {
      const lastDay = D(utcDate(y, m + 1, 0))
      const d = utcDate(y, m, Math.min(day, lastDay) + dayOffset)
      if (d > from) results.push(d)
      m++; if (m > 11) { m = 0; y++ }
    }
  }

  return results.slice(0, count)
}

function CalendarGrid({ year, month, payDates, todayUTC }) {
  const firstDay = DAY(utcDate(year, month, 1))
  const daysInMonth = D(utcDate(year, month + 1, 0))
  const cells = []

  for (let i = 0; i < firstDay; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(d)

  const isToday = (d) => d && Y(todayUTC) === year && M(todayUTC) === month && D(todayUTC) === d
  const isPay   = (d) => d && payDates.has(d)

  return (
    <div style={{ padding: '0 10px 10px' }}>
      {/* Day headers */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2, marginBottom: 3 }}>
        {DAYS.map(d => (
          <div key={d} style={{ textAlign: 'center', fontSize: 8, fontFamily: 'JetBrains Mono', color: 'var(--text-label)', fontWeight: 700, padding: '3px 0', letterSpacing: '0.04em' }}>
            {d}
          </div>
        ))}
      </div>

      {/* Date cells */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
        {cells.map((d, i) => (
          <div key={i} style={{
            height: 28,
            borderRadius: 7,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 11,
            fontFamily: 'JetBrains Mono',
            fontWeight: isPay(d) ? 800 : isToday(d) ? 700 : 400,
            background: isPay(d)
              ? 'linear-gradient(135deg,var(--accent),var(--accent-2))'
              : isToday(d)
              ? 'var(--accent-soft)'
              : 'transparent',
            color: isPay(d)
              ? '#fff'
              : isToday(d)
              ? 'var(--accent-muted)'
              : d ? 'var(--text-primary)' : 'transparent',
            border: isToday(d) && !isPay(d) ? '1px solid rgba(99,102,241,0.3)' : '1px solid transparent',
            boxShadow: isPay(d) ? '0 2px 8px rgba(99,102,241,0.35)' : 'none',
            transition: 'all 0.15s',
            position: 'relative',
          }}>
            {d || ''}
            {isPay(d) && (
              <span style={{ position: 'absolute', bottom: 2, right: 3, fontSize: 6, opacity: 0.8 }}>💰</span>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default function JPCal({ focused = true, onFocus = () => {} }) {
  const now = new Date()
  const todayUTC = utcDate(now.getFullYear(), now.getMonth(), now.getDate())
  const [expanded, setExpanded]     = useState(true)
  const [position, setPosition]     = useState({ x: window.innerWidth - 460, y: 90 })
  const [dragging, setDragging]     = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [viewYear, setViewYear]     = useState(now.getFullYear())
  const [viewMonth, setViewMonth]   = useState(now.getMonth())
  const [frequency, setFrequency]   = useState('weekly')
  const [startDate, setStartDate]   = useState('')

  const payDates = getPayDates(frequency, startDate, viewYear, viewMonth)
  const upcomingDates = getUpcomingPayDates(frequency, startDate, startDate ? parseDate(startDate) : todayUTC, 4)

  // ── Drag ──────────────────────────────────────────────────
  const handleWidgetMouseDown = useCallback((e) => {
    onFocus()
    if (!e.target.closest('button') && !e.target.closest('input') && !e.target.closest('select')) {
      setDragging(true)
      setDragOffset({ x: e.clientX - position.x, y: e.clientY - position.y })
    }
  }, [position, onFocus])

  useEffect(() => {
    if (!dragging) return
    const onMove = (e) => {
      setPosition({
        x: Math.max(0, Math.min(e.clientX - dragOffset.x, window.innerWidth - 240)),
        y: Math.max(0, Math.min(e.clientY - dragOffset.y, window.innerHeight - (expanded ? 420 : 44))),
      })
    }
    const onUp = () => setDragging(false)
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp) }
  }, [dragging, dragOffset, expanded])

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1) }
    else setViewMonth(m => m - 1)
  }
  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1) }
    else setViewMonth(m => m + 1)
  }

  const payCount = payDates.size

  return (
    <div
      data-theme="dark"
      onMouseDown={handleWidgetMouseDown}
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y,
        width: 240,
        zIndex: focused ? 9999 : 9990,
        borderRadius: expanded ? 18 : 12,
        background: '#111827',
        border: `1px solid ${focused ? 'var(--accent-border)' : 'var(--border)'}`,
        boxShadow: focused ? '0 8px 40px rgba(0,0,0,0.55)' : '0 4px 20px rgba(0,0,0,0.3)',
        overflow: 'hidden',
        transition: dragging ? 'none' : 'border-radius 0.25s ease, box-shadow 0.2s ease, border-color 0.2s ease',
        cursor: dragging ? 'grabbing' : 'default',
        userSelect: 'none',
        fontFamily: 'Space Grotesk'
      }}
    >
      {/* ── Header ── */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '12px 14px',
        background: '#111827',
        borderBottom: expanded ? '1px solid var(--border)' : 'none',
        cursor: dragging ? 'grabbing' : 'grab',
      }}>
        <CalIcon size={22} iconSize={13} />
        <span style={{ fontFamily: 'Space Grotesk', fontWeight: 800, fontSize: 14, letterSpacing: '-0.02em', color: 'var(--text-primary)' }}>
          JP<span style={{ background: 'linear-gradient(90deg,var(--accent),var(--accent-2))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Cal</span>
        </span>
        <div style={{ flex: 1 }} />
        <button
          onClick={() => setExpanded(v => !v)}
          style={{
            background: 'var(--surface-2)', border: '1px solid var(--border)',
            borderRadius: 6, color: 'var(--text-muted)', cursor: 'pointer',
            width: 24, height: 24, display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: 11, flexShrink: 0,
          }}
          title={expanded ? 'Minimize' : 'Expand'}
        >
          {expanded ? '▼' : '▲'}
        </button>
      </div>

      {expanded && (
        <div style={{ display: 'flex', flexDirection: 'column', background: '#0A0E1A' }}>

          {/* ── Config panel ── */}
          <div style={{ padding: '10px 12px 8px', background: 'var(--bg)', borderBottom: '1px solid var(--border)' }}>

            {/* Frequency selector */}
            <div style={{ marginBottom: 8 }}>
              <div style={{ fontSize: 9, fontFamily: 'JetBrains Mono', color: 'var(--text-label)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 5, fontWeight: 700 }}>
                Pay Frequency
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
                {FREQUENCIES.map(f => (
                  <button
                    key={f.id}
                    onClick={() => setFrequency(f.id)}
                    style={{
                      padding: '5px 4px',
                      borderRadius: 8,
                      border: `1px solid ${frequency === f.id ? 'var(--accent-border)' : 'var(--border)'}`,
                      background: frequency === f.id ? 'var(--accent-soft)' : 'var(--surface)',
                      color: frequency === f.id ? 'var(--accent-muted)' : 'var(--text-muted)',
                      fontFamily: 'JetBrains Mono',
                      fontSize: 10,
                      fontWeight: frequency === f.id ? 700 : 400,
                      cursor: 'pointer',
                      transition: 'all 0.15s',
                      textAlign: 'center',
                    }}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Start date */}
            <div>
              <div style={{ fontSize: 9, fontFamily: 'JetBrains Mono', color: 'var(--text-label)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 5, fontWeight: 700 }}>
                {frequency === 'weekly' || frequency === 'biweekly' ? 'First Pay Date' : 'First Pay Date'}
              </div>
              <input
                type="date"
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                style={{
                  width: '100%',
                  padding: '6px 8px',
                  borderRadius: 8,
                  border: '1px solid var(--border)',
                  background: 'var(--surface)',
                  color: 'var(--text-primary)',
                  fontFamily: 'JetBrains Mono',
                  fontSize: 11,
                  boxSizing: 'border-box',
                  outline: 'none',
                  colorScheme: 'dark',
                }}
              />
            </div>
          </div>

          {/* ── Month nav ── */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px 4px', background: 'var(--surface)' }}>
            <button onClick={prevMonth} style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text-muted)', cursor: 'pointer', width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10 }}>‹</button>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'Space Grotesk', fontWeight: 800, fontSize: 13, color: 'var(--text-primary)' }}>{MONTHS[viewMonth]}</div>
              <div style={{ fontFamily: 'JetBrains Mono', fontSize: 9, color: 'var(--text-label)' }}>{viewYear}</div>
            </div>
            <button onClick={nextMonth} style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text-muted)', cursor: 'pointer', width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10 }}>›</button>
          </div>

          {/* ── Calendar grid ── */}
          <CalendarGrid year={viewYear} month={viewMonth} payDates={payDates} todayUTC={todayUTC} />

          {/* ── Upcoming paydays summary ── */}
          {startDate && upcomingDates.length > 0 && (
            <div style={{ padding: '8px 12px', borderTop: '1px solid var(--border)', background: 'var(--bg)' }}>
              <div style={{ fontSize: 9, fontFamily: 'JetBrains Mono', color: 'var(--text-label)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 700, marginBottom: 6 }}>
                ⏭ Next {upcomingDates.length} Paydays
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {upcomingDates.map((d, i) => {
                  const isNextPay = i === 0
                  return (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '5px 8px', borderRadius: 8,
                      background: isNextPay ? 'var(--accent-soft)' : 'var(--surface)',
                      border: `1px solid ${isNextPay ? 'var(--accent-border)' : 'var(--border)'}`,
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 10 }}>{isNextPay ? '💰' : '📆'}</span>
                        <span style={{ fontFamily: 'Space Grotesk', fontWeight: 700, fontSize: 11, color: isNextPay ? 'var(--accent-muted)' : 'var(--text-primary)' }}>
                          {SHORT_DAYS[DAY(d)]}, {SHORT_MONTHS[M(d)]} {D(d)}
                        </span>
                      </div>
                      <span style={{ fontFamily: 'JetBrains Mono', fontSize: 9, color: isNextPay ? 'var(--accent-muted)' : 'var(--text-muted)', fontWeight: isNextPay ? 700 : 400 }}>
                        {Y(d)}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* ── Footer ── */}
          <div style={{ padding: '6px 14px', borderTop: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 9, fontFamily: 'JetBrains Mono', color: 'var(--text-label)', letterSpacing: '0.08em' }}>JPCAL v1.0</span>
            {payCount > 0 && startDate ? (
              <span style={{ fontSize: 9, fontFamily: 'JetBrains Mono', color: 'var(--accent-muted)', fontWeight: 700 }}>
                💰 {payCount} pay day{payCount !== 1 ? 's' : ''} this month
              </span>
            ) : (
              <span style={{ fontSize: 9, fontFamily: 'JetBrains Mono', color: 'var(--text-label)' }}>set a date to highlight</span>
            )}
          </div>

        </div>
      )}
    </div>
  )
}
